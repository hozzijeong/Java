package _10_rpg;

public class d {
	public static void main(String[] args) {
		System.out.println("\rn");
	}
}
